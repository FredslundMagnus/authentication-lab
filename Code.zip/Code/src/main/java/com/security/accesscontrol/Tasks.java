package com.security.accesscontrol;

enum Tasks {
    AccessControlList,
    RoleBased,
    AccessControlListAfterChange,
    RoleBasedAfterChange,
}
